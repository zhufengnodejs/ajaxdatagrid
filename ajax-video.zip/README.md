#简介
本项目是打算用bootstrap+angular+node.js+restify+gulp做一个前后端结合的AJAX单页grid restful应用。
提供增加、删、改、查，分页等功能。

#技术选型
##bower
##bootstrap
##angular
##node.js
##gulp
##karma-coverage
##git
##Protractor
##Jasmine


#初始化项目
1. 初始化bower
```bower init```
2. 编写.bowerrc
```{"directory":"public/lib"}```
3. 添加前端框架
```bower install bootstrap```
```bower install angular```
```bower install angular-route```
4. 初始化npm
```npm init```
5. 安装restify
```npm install restify```



