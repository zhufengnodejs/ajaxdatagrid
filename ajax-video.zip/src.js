function reverse(name){
    return name.split("").reverse().join("");
}